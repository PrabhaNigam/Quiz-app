var questions = [
    {
          "question":"Grand Central Terminal, Park Avenue, New York is the world's." ,
           "option1":"largest railway station",
           "option2":"highest railway station",
           "option3":"longest railway station",
           "option4":"None of the above",
            "answer":"1"
    },

    {
            "question":"Entomology is the science that studies.",
             "option1":"Behavior of human beings",
             "option2":"Insects",
             "option3":"The origin and history of technical and scientific terms",
             "option4":"The formation of rocks",
             "answer":"2"
    },

    {
         "question":"Eritrea, which became the 182nd member of the UN in 1993, is in the continent of",
      
          "option1":"Asia",
          "option2":"Africa",
          "option3":"Europe",
           "option4":"Australia",
           "answer":"2"
    },

    {   "question":"Garampani sanctuary is located at",
     
         "option1":"Junagarh,Gujarat",
           "option2":"Diphu,Assam",
          "option3":"Kohima, Nagaland",
          "option4":"Gangtok, Sikkim",
          "answer":"2"
    },

    {
          "question":"Hitler party which came into power in 1933 is known as",
        
            "option1":"Labour Party",
             "option2":"Nazi Party",
             "option3":"Ku-Klux-Klan",
             "option4":"Democratic Party",
             "answer":"2"
    }
];
 